# Bingr TV (Google TV Android project)

A simple Android TV-friendly launcher for https://bingr.one/ with a custom home screen and a WebView for the site.

## Build the APK
1. Install Android Studio on a computer.
2. Open this `BingrTV` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK will be in `app/build/outputs/apk/debug/app-debug.apk`.

## Install on Google TV
1. Copy the APK to a USB drive or send it to the TV using a file-transfer app.
2. Open it with a file manager on Google TV and allow installation from that source.
3. Install **Bingr TV** and launch it from Apps.

## Notes
- This is a source project, not a prebuilt APK. An Android SDK/Android Studio build environment is required to compile it.
- Website login, video playback, DRM, pop-ups, and remote navigation depend on the website and its video player. Some websites intentionally block embedded WebViews; if Bingr does, the app may need to open the site in the TV's supported browser instead.
- This app only displays the website; it does not download or store its videos.
