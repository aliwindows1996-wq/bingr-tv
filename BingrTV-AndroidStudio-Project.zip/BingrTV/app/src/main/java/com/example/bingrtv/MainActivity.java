package com.example.bingrtv;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://bingr.one/";
    private FrameLayout root;
    private WebView webView;
    private View homeScreen;
    private boolean browsing = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8, 10, 17));
        setContentView(root);
        buildHome();
    }

    private GradientDrawable rounded(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(24f);
        if (stroke != 0) d.setStroke(3, stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildHome() {
        browsing = false;
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(76, 48, 76, 42);
        page.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(24, 28, 48), Color.rgb(8, 10, 17), Color.rgb(35, 17, 29)}));

        TextView brand = text("BINGR", 34, Color.rgb(245,197,24), true);
        page.addView(brand, new LinearLayout.LayoutParams(-1, 58));

        TextView title = text("Your entertainment,\non the big screen.", 42, Color.WHITE, true);
        title.setLineSpacing(2f, 1.0f);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, 150);
        titleLp.topMargin = 24;
        page.addView(title, titleLp);

        TextView subtitle = text("Movies  •  Series  •  Anime  •  More", 20, Color.rgb(190,194,207), false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, 52);
        subLp.topMargin = 8;
        page.addView(subtitle, subLp);

        Button watch = makeButton("▶   WATCH BINGR", true);
        LinearLayout.LayoutParams watchLp = new LinearLayout.LayoutParams(340, 76);
        watchLp.topMargin = 34;
        page.addView(watch, watchLp);
        watch.setOnClickListener(v -> openWebsite());

        Button exit = makeButton("EXIT APP", false);
        LinearLayout.LayoutParams exitLp = new LinearLayout.LayoutParams(220, 62);
        exitLp.topMargin = 16;
        page.addView(exit, exitLp);
        exit.setOnClickListener(v -> finish());

        TextView hint = text("Use your TV remote: arrows to move  •  OK to select  •  Back to return", 15, Color.rgb(145,150,166), false);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, 50);
        hintLp.topMargin = 22;
        page.addView(hint, hintLp);

        homeScreen = page;
        root.removeAllViews();
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));
        watch.requestFocus();
    }

    private Button makeButton(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(18); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.rgb(14,15,20) : Color.WHITE);
        b.setBackground(primary ? rounded(Color.rgb(245,197,24), 0) : rounded(Color.rgb(45,48,62), Color.rgb(90,94,112)));
        b.setFocusable(true); b.setFocusableInTouchMode(true);
        b.setOnFocusChangeListener((v, focused) -> {
            v.setScaleX(focused ? 1.04f : 1f); v.setScaleY(focused ? 1.04f : 1f);
            v.setBackground(focused ? rounded(Color.rgb(255,222,91), Color.WHITE) :
                    (primary ? rounded(Color.rgb(245,197,24), 0) : rounded(Color.rgb(45,48,62), Color.rgb(90,94,112))));
        });
        return b;
    }

    private void openWebsite() {
        browsing = true;
        root.removeAllViews();
        if (webView == null) {
            webView = new WebView(this);
            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setMediaPlaybackRequiresUserGesture(false);
            s.setLoadWithOverviewMode(true);
            s.setUseWideViewPort(true);
            s.setBuiltInZoomControls(false);
            s.setSupportZoom(false);
            CookieManager.getInstance().setAcceptCookie(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
            webView.setWebChromeClient(new WebChromeClient());
            webView.setWebViewClient(new WebViewClient());
            webView.setBackgroundColor(Color.BLACK);
        }
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        if (webView.getUrl() == null) webView.loadUrl(HOME_URL);
        else webView.onResume();
        webView.requestFocus();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_UP && event.getKeyCode() == KeyEvent.KEYCODE_BACK && browsing) {
            if (webView != null && webView.canGoBack()) webView.goBack();
            else buildHome();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override protected void onPause() { if (webView != null) webView.onPause(); super.onPause(); }
    @Override protected void onDestroy() { if (webView != null) { webView.destroy(); webView = null; } super.onDestroy(); }
}
